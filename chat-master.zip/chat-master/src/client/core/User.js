class User {
  constructor({ id, nickname, avatarUrl }) {
    this.id = id;
    this.nickname = nickname;
    this.avatarUrl = avatarUrl;
  }
}

export default User;
